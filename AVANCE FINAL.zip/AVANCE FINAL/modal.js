document.addEventListener('DOMContentLoaded', function () {
  ///MODAL DE VER MAS EVENTOS///
  const open = document.getElementById('open');
  const modal_container = document.getElementById('modal_container');
  const close = document.getElementById('close');

  open.addEventListener('click', () => {
    modal_container.classList.add('show');
    document.body.classList.add('modal-open');
  });

  close.addEventListener('click', () => {
    modal_container.classList.remove('show');
    document.body.classList.remove('modal-open');
  });

  // Cerrar el modal si se hace clic fuera de él
  modal_container.addEventListener('click', (e) => {
    if (e.target === modal_container) {
      modal_container.classList.remove('show');
      document.body.classList.remove('modal-open');
    }
  });

  ///MODAL DE AUTENTICACIÓN///
  const adminOpen = document.getElementById('adminOpen');
  const auth_modal_container = document.getElementById('auth_modal_container');
  const admin_modal_container = document.getElementById('admin_modal_container');
  const authClose = document.getElementById('authClose');
  const authForm = document.getElementById('authForm');

  // Credenciales de administrador (no es seguro en producción)
  const ADMIN_USERNAME = 'admin';
  const ADMIN_PASSWORD = '12345';

  adminOpen.addEventListener('click', () => {
    auth_modal_container.classList.add('show');
    document.body.classList.add('modal-open');
  });

  authClose.addEventListener('click', () => {
    auth_modal_container.classList.remove('show');
    document.body.classList.remove('modal-open');
  });

  authForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
      // Autenticación exitosa
      auth_modal_container.classList.remove('show');
      admin_modal_container.classList.add('show');
      authForm.reset(); // Limpia el formulario
    } else {
      alert('Usuario o contraseña incorrectos');
      authForm.reset(); // Limpia el formulario
    }
  });

  // Cerrar el modal si se hace clic fuera de él
  auth_modal_container.addEventListener('click', (e) => {
    if (e.target === auth_modal_container) {
      auth_modal_container.classList.remove('show');
      document.body.classList.remove('modal-open');
    }
  });

  ///MODAL DE AGREGAR EVENTOS///
  const adminClose = document.getElementById('adminClose');
  const eventForm = document.getElementById('eventForm');

  adminClose.addEventListener('click', () => {
    admin_modal_container.classList.remove('show');
    document.body.classList.remove('modal-open');
  });

  admin_modal_container.addEventListener('click', (e) => {
    if (e.target === admin_modal_container) {
      admin_modal_container.classList.remove('show');
      document.body.classList.remove('modal-open');
    }
  });

  const nuevosEventos = document.getElementById('nuevos-eventos');

  eventForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const formData = new FormData(eventForm);

    fetch('slider.php', {
      method: 'POST',
      body: formData
    })
      .then(response => response.json())
      .then(data => {
        if (data.success) {
          // Crear y agregar el nuevo evento al DOM
          const nuevoEvento = createEventElement(
            formData.get('titulo'),
            formatDate(formData.get('fecha')),
            URL.createObjectURL(formData.get('imagen'))
          );
          nuevosEventos.appendChild(nuevoEvento);
          
          // Cerrar el modal y limpiar el formulario
          admin_modal_container.classList.remove('show');
          document.body.classList.remove('modal-open');
          eventForm.reset();
        } else {
          alert('Error al guardar el evento: ' + data.message);
        }
      })
      .catch(error => {
        console.error('Error:', error);
        alert('Error al guardar el evento');
      });
  });

});

function formatDate(dateString) {
  const date = new Date(dateString);
  const day = date.getDate().toString().padStart(2, '0');
  const month = date.toLocaleString('es', { month: 'short' });
  return `${day}${month}`;
}

function createEventElement(title, date, imageSrc) {
  const carrusel = document.createElement('div');
  carrusel.className = 'carrusel';
  carrusel.innerHTML = `
      <a href="#">
          <h4><small>${title}</small> ${date}</h4>
          <picture>
              <img src="${imageSrc}" alt="${title}">
          </picture>
      </a>
  `;
  return carrusel;
}

// En el evento submit del formulario
fetch('slider.php', {
  method: 'POST',
  body: formData
})
.then(response => response.json())
.then(data => {
  if (data.success) {
    const nuevoEvento = createEventElement(
      formData.get('titulo'),
      formatDate(formData.get('fecha')),
      data.imagePath // Usa la ruta de la imagen devuelta por el servidor
    );
    nuevosEventos.appendChild(nuevoEvento);
    
    // Cerrar el modal y limpiar el formulario
    admin_modal_container.classList.remove('show');
    document.body.classList.remove('modal-open');
    eventForm.reset();
  } else {
    alert('Error al guardar el evento: ' + data.message);
  }
})
.catch(error => {
  console.error('Error:', error);
  alert('Error al guardar el evento');
});
