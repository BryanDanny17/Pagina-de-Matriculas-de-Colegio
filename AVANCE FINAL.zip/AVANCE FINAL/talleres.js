/* Selecciona y guardamoe en una cte la clase del botón de menú. */
const navToggle = document.querySelector(".icono-hamburguesa")

/*Selecciona y guardamoe en una cte la clase del menú de navegación. */
const ulPrincipal = document.querySelector(".ul-principal")


/*addEventListener("click", ...): Agrega un evento de clic al botón de menú.*/
/*La función que se pasa como argumento a addEventListener se 
ejecuta cada vez que el usuario hace clic en el botón navToggle. */

/*Lo q hace classList.toggle("menu_visble") es preguntarme si existe dentro mi elemento
"ul-principal" una clase "nav-menu_visble" si no existe la agrega,
 quedaria asi(<ul class="ul-principal menu_visble">), y si existe la elimina:
 <ul class="ul-principal"> */
navToggle.addEventListener("click", () => {
    ulPrincipal.classList.toggle("menu_visble")
})


function reproducirAudio() {
    var audio = document.getElementById("audio-himno");
    if (audio.paused) {
        audio.play();
    } else {
        audio.pause();
        audio.currentTime = 0;
    }
}

ScrollReveal().reveal('.tag', {
    delay: 375,
    duration: 500,
    reset: false,
    interval: 100
});
ScrollReveal().reveal('.item-menu', {
    delay: 375,
    duration: 500,
    reset: false,
    interval: 100
});
ScrollReveal().reveal('.contenido-danza', {
    delay: 375,
    duration: 500,
    reset: false,
    interval: 100
});
ScrollReveal().reveal('.imagen-danza', {
    delay: 375,
    duration: 500,
    reset: false,
    interval: 100
});
ScrollReveal().reveal('.contenido-futbol', {
    delay: 375,
    duration: 500,
    reset: false,
    interval: 100
});
ScrollReveal().reveal('.imagen-futbol', {
    delay: 375,
    duration: 500,
    reset: false,
    interval: 100
});
ScrollReveal().reveal('.contenido-voley', {
    delay: 375,
    duration: 500,
    reset: false,
    interval: 100
});
ScrollReveal().reveal('.imagen-voley', {
    delay: 375,
    duration: 500,
    reset: false,
    interval: 100
});
ScrollReveal().reveal('.contenido-ajedrez', {
    delay: 375,
    duration: 500,
    reset: false,
    interval: 100
});
ScrollReveal().reveal('.imagen-ajedrez', {
    delay: 375,
    duration: 500,
    reset: false,
    interval: 100
});
ScrollReveal().reveal('.contenido-computacion', {
    delay: 375,
    duration: 500,
    reset: false,
    interval: 100
});
ScrollReveal().reveal('.imagen-computacion', {
    delay: 375,
    duration: 500,
    reset: false,
    interval: 100
});
ScrollReveal().reveal('.contenido-canto', {
    delay: 375,
    duration: 500,
    reset: false,
    interval: 100
});
ScrollReveal().reveal('.imagen-canto', {
    delay: 375,
    duration: 500,
    reset: false,
    interval: 100
});

