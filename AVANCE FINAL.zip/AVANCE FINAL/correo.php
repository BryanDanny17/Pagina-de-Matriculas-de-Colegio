<?php
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    header("Location: contactanos.html");
    exit();
}

require 'phpmailer/PHPMailer.php';
require 'phpmailer/Exception.php';
require 'phpmailer/SMTP.php'; // Asegúrate de incluir también el archivo SMTP

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$correo = $_POST['correo'];
$telefono = $_POST['telefono'];
$sexo = $_POST['sexo'];
$comentario = $_POST['comentario'];

// Comprobar cuál campo de grado tiene un valor seleccionado
$grado = '';
if (!empty($_POST['kinder-grado'])) {
    $grado = $_POST['kinder-grado'];
} elseif (!empty($_POST['primaria-grado'])) {
    $grado = $_POST['primaria-grado'];
} elseif (!empty($_POST['secundaria-grado'])) {
    $grado = $_POST['secundaria-grado'];
}


if (empty(trim($nombre))) $nombre = 'anonimo';
if (empty(trim($apellido))) $apellido = '';


$asunto = "¡Datos de: $nombre !";
$asunto = mb_encode_mimeheader($asunto, 'UTF-8', 'B', "\r\n");
$body = '
<html>
    <head>
        <title>Prueba de envio correo</title>
    </head>
    <body>
        <h1>¡'. $nombre . ' Quiere ser parte de nuestra familia!</h1>
        <p>
            Contacto: ' . $nombre . ' ' . $apellido . '<br>
            Grado: '.$grado. '<br>
            Correo: '.$correo. '<br>
            Teléfono: '.$telefono. '<br>
            <b> <hr> Comentario:</b> <br>'.$comentario.'
        </p>
    </body>
</html>';


try {
    $mailer = new PHPMailer(true);
    // Configuración del servidor SMTP
    $mailer->isSMTP();
    $mailer->Host = 'smtp.gmail.com'; // Cambia esto por tu servidor SMTP
    $mailer->SMTPAuth = true;
    $mailer->Username = 'virgendellourdess@gmail.com'; // Cambia esto por tu usuario SMTP
    $mailer->Password = 'ayna fgzf chae ohhk'; // Cambia esto por tu contraseña SMTP
    $mailer->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mailer->Port = 587; // Cambia esto por el puerto de tu servidor SMTP, generalmente 587 o 465

    // Configuración del correo
    $mailer->setFrom($correo, "$nombre $apellido"); //remitente
    $mailer->addAddress('virgendellourdess@gmail.com', 'Sitio Web'); //receptor
    $mailer->Subject = $asunto;
    $mailer->msgHTML($body); //el cuerpo del correo que hemos creado en HTML
    $mailer->AltBody = strip_tags($body);

    // Enviar el correo
    $rta = $mailer->send();
    var_dump($rta);

    // Mostrar alerta y redirigir con JavaScript

    echo "<script>
            alert('¡El formulario se ha enviado con éxito :)!');

            setTimeout(function() {
                window.location.href = 'contactanos.html'; // Redirige al formulario
            }, 10); // Redirige después de 0.01 segundo
        </script>";

} catch (Exception $e) {
    echo "<script>
            alert('¡El formulario no pudo ser enviado:( !. Error de PHPMailer: {$mailer->ErrorInfo}');
            window.location.href = 'contactanos.html'; // Redirige al formulario
        </script>";
}
