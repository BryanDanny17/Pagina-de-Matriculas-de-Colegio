const chatbotToggler = document.querySelector(".chatbot-toggler");
const closeBtn = document.querySelector(".close-btn");
const chatbox = document.querySelector(".chatbox");
const chatInput = document.querySelector(".chat-input textarea");
const sendChatBtn = document.querySelector(".chat-input span");
let enlaceW = "https://wa.link/zpe55z";
let infoW = "https://wa.link/g5k0tw";
let ubicaMaps = "https://maps.app.goo.gl/Ps2h7Kd3zWMZbTvd6";

let userMessage = null; // Variable to store user's message
const inputInitHeight = chatInput.scrollHeight;

const responses = {
    "hola": "Hola, bienvenido al chatbot del colegio Virgen del Lourdes. ¿Qué desea?",
    "cuando es la matricula": "La matrícula será el 15 de febrero de 9:00 am a 4:00 pm.",
    "¿qué dia es la matricula?": "La matrícula será el 15 de febrero de 9:00 am a 4:00 pm.",
    "dia de la matricula": "La matrícula será el 15 de febrero de 9:00 am a 4:00 pm.",
    "que fecha es la matricula": "La matrícula será el 15 de febrero de 9:00 am a 4:00 pm.",
    "¿que fecha es la matricula?": "La matrícula será el 15 de febrero de 9:00 am a 4:00 pm.",
    "documentos para matricula": "Para la matrícula necesitas traer tu acta de nacimiento, dni, comprobante de domicilio, y boleta de calificaciones.",
    "¿qué documentos debo llevar para matricular a mi hijo?": "Para la matrícula necesitas traer tu acta de nacimiento, dni, comprobante de domicilio, y boleta de calificaciones.",
    "que documentos debo llevar para matricular a mi hijo": "Para la matrícula necesitas traer tu acta de nacimiento, dni, comprobante de domicilio, y boleta de calificaciones.",
    "que documentos debo llevar para la matricula": "Para la matrícula necesitas traer tu acta de nacimiento, dni, comprobante de domicilio, y boleta de calificaciones.",
    "hora de la matricula": "La matrícula será de 9:00 am a 12:00 pm.",
    "información": `Presiona en el siguiente <a href="${infoW}" target="_blank">enlace</a> para más información.`,
    "deseo más información sobre la matricula": `Presiona en el siguiente <a href="${enlaceW}" target="_blank">enlace</a> para hablar con un supervisor.`,
    "quiero matricular a mi hijo": `Presiona en el siguiente <a href="${enlaceW}" target="_blank">enlace</a> para hablar con un supervisor.`,
    "ubicación": `La matricula se realizara en la institución 6006 - Pachacamac. Presiona el <a href="${ubicaMaps}" target="_blank">enlace</a> para ver la ubicación.`,
    "donde sera la matricula": `La matricula se realizara en la institución 6006 - Pachacamac. Presiona el <a href="${ubicaMaps}" target="_blank">enlace</a> para ver la ubicación.`,
    "¿dónde sera la matricula?": `La matricula se realizara en la institución 6006 - Pachacamac. Presiona el <a href="${ubicaMaps}" target="_blank">enlace</a> para ver la ubicación.`,
    "¿lugar de la matricula?": `La matricula se realizara en la institución 6006 - Pachacamac. Presiona el <a href="${ubicaMaps}" target="_blank">enlace</a> para ver la ubicación.`,
    "lugar de la matricula": `La matricula se realizara en la institución 6006 - Pachacamac. Presiona el <a href="${ubicaMaps}" target="_blank">enlace</a> para ver la ubicación.`,
};

const createChatLi = (message, className) => {
    const chatLi = document.createElement("li");
    chatLi.classList.add("chat", `${className}`);
    let chatContent = className === "outgoing" ? `<p></p>` : `<span class="material-symbols-outlined">smart_toy</span><p></p>`;
    chatLi.innerHTML = chatContent;
    chatLi.querySelector("p").textContent = message;
    return chatLi; // return chat <li> element
}

const generateResponse = (chatElement, userMessage) => {
    const messageElement = chatElement.querySelector("p");
    const response = getResponse(userMessage);
    messageElement.innerHTML = response;
    chatbox.scrollTo(0, chatbox.scrollHeight);
}

const getResponse = (message) => {
    message = message.toLowerCase();
    for (const key in responses) {
        if (message.includes(key)) {
            return responses[key];
        }
    }
    return "Lo siento, no entiendo tu pregunta. Por favor intenta con otra consulta.";
}

const handleChat = () => {
    userMessage = chatInput.value.trim(); // Get user entered message and remove extra whitespace
    if (!userMessage) return;

    // Clear the input textarea and set its height to default
    chatInput.value = "";
    chatInput.style.height = `${inputInitHeight}px`;

    // Append the user's message to the chatbox
    chatbox.appendChild(createChatLi(userMessage, "outgoing"));
    chatbox.scrollTo(0, chatbox.scrollHeight);

    setTimeout(() => {
        // Display the response based on user message
        const incomingChatLi = createChatLi("", "incoming");
        chatbox.appendChild(incomingChatLi);
        chatbox.scrollTo(0, chatbox.scrollHeight);
        generateResponse(incomingChatLi, userMessage);
    }, 600);
}

chatInput.addEventListener("input", () => {
    // Adjust the height of the input textarea based on its content
    chatInput.style.height = `${inputInitHeight}px`;
    chatInput.style.height = `${chatInput.scrollHeight}px`;
});

chatInput.addEventListener("keydown", (e) => {
    // If Enter key is pressed without Shift key and the window 
    // width is greater than 800px, handle the chat
    if (e.key === "Enter" && !e.shiftKey && window.innerWidth > 800) {
        e.preventDefault();
        handleChat();
    }
});

sendChatBtn.addEventListener("click", handleChat);
closeBtn.addEventListener("click", () => document.body.classList.remove("show-chatbot"));
chatbotToggler.addEventListener("click", () => document.body.classList.toggle("show-chatbot"));


ScrollReveal().reveal('.circulo-section', {
    delay: 400,
    duration: 500,
    reset: false,
    interval: 100
});

ScrollReveal().reveal('.box1', {
    delay: 375,
    duration: 500,
    reset: false,
    interval: 100
});

ScrollReveal().reveal('.img1', {
    delay: 375,
    duration: 500,
    reset: false,
    interval: 100
});
