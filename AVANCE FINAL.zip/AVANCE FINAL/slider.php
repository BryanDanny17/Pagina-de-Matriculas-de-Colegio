<?php
// Habilitar reporte de errores
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Conexión a la base de datos
$servername = "localhost";
$username = "u859308022_brian";
$password = "Grupo912345678910";
$dbname = "u859308022_slider";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Función para agregar un nuevo evento
function agregarEvento($titulo, $fecha, $imagen) {
    global $conn;
    $sql = "INSERT INTO eventos (titulo, fecha, imagen) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $titulo, $fecha, $imagen);
    return $stmt->execute();
}

// Manejo de la solicitud POST para agregar un nuevo evento
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titulo = $_POST["titulo"];
    $fecha = $_POST["fecha"];
    
    // Verificar si se subió un archivo
    if(isset($_FILES["imagen"]) && $_FILES["imagen"]["error"] == 0) {
        $imagen = $_FILES["imagen"]["name"];
        $target_dir = "../uploads/"; // Cambiado a una carpeta fuera del directorio público
        $target_file = $target_dir . basename($_FILES["imagen"]["name"]);
        
        // Verificar si el directorio existe, si no, crearlo
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0755, true);
        }
        
        // Intentar mover el archivo subido
        if (move_uploaded_file($_FILES["imagen"]["tmp_name"], $target_file)) {
            if (agregarEvento($titulo, $fecha, $target_file)) {
                echo json_encode(["success" => true, "message" => "Evento agregado con éxito"]);
            } else {
                echo json_encode(["success" => false, "message" => "Error al guardar en la base de datos: " . $conn->error]);
            }
        } else {
            echo json_encode(["success" => false, "message" => "Error al subir la imagen: " . $_FILES["imagen"]["error"]]);
        }
    } else {
        echo json_encode(["success" => false, "message" => "No se subió ninguna imagen o hubo un error en la subida"]);
    }
    exit;
}
?>